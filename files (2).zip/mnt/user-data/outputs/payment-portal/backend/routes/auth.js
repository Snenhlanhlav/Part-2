const express = require("express");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { REGEX } = require("../models/User");

const router = express.Router();

// ─── Helper: Whitelist-validate all fields before processing ─────────────────
function validateRegistrationInput({ fullName, idNumber, accountNumber, username, password }) {
  const errors = [];

  if (!REGEX.fullName.test(fullName))
    errors.push("Full name must be 2-100 characters, letters and spaces only.");
  if (!REGEX.idNumber.test(idNumber))
    errors.push("ID number must be exactly 13 digits.");
  if (!REGEX.accountNumber.test(accountNumber))
    errors.push("Account number must be 8-16 digits.");
  if (!REGEX.username.test(username))
    errors.push("Username must be 3-30 characters (letters, numbers, _ . -).");
  if (!REGEX.password.test(password))
    errors.push(
      "Password must be at least 8 characters and include uppercase, lowercase, number, and special character."
    );

  return errors;
}

function validateLoginInput({ username, accountNumber, password }) {
  const errors = [];
  if (!REGEX.username.test(username)) errors.push("Invalid username format.");
  if (!REGEX.accountNumber.test(accountNumber)) errors.push("Invalid account number format.");
  if (!password || password.length < 8) errors.push("Invalid password.");
  return errors;
}

// ─── POST /api/auth/register ──────────────────────────────────────────────────
router.post("/register", async (req, res) => {
  try {
    const { fullName, idNumber, accountNumber, username, password } = req.body;

    // 1. Whitelist validation
    const errors = validateRegistrationInput({ fullName, idNumber, accountNumber, username, password });
    if (errors.length > 0) {
      return res.status(400).json({ errors });
    }

    // 2. Check for existing user (prevent duplicate accounts)
    const existingUser = await User.findOne({
      $or: [{ username }, { idNumber }, { accountNumber }],
    });
    if (existingUser) {
      // Generic error — don't reveal which field matched (prevents enumeration attacks)
      return res.status(409).json({ error: "An account with these details already exists." });
    }

    // 3. Create user — password hashed automatically via pre-save hook
    const user = new User({ fullName, idNumber, accountNumber, username, password, role: "customer" });
    await user.save();

    res.status(201).json({ message: "Account created successfully. You may now log in." });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ error: "Registration failed. Please try again." });
  }
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
router.post("/login", async (req, res) => {
  try {
    const { username, accountNumber, password } = req.body;

    // 1. Whitelist validation
    const errors = validateLoginInput({ username, accountNumber, password });
    if (errors.length > 0) {
      return res.status(400).json({ errors });
    }

    // 2. Find user
    const user = await User.findOne({ username, accountNumber });

    // 3. Compare password — use the same timing whether user exists or not
    //    (prevents timing-based username enumeration)
    const passwordMatch = user ? await user.comparePassword(password) : false;

    if (!user || !passwordMatch) {
      // Generic message — don't reveal which field was wrong
      return res.status(401).json({ error: "Invalid credentials. Please try again." });
    }

    // 4. Issue JWT — short-lived (1 hour) for session security
    const token = jwt.sign(
      { id: user._id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({
      message: "Login successful.",
      token,
      user: { username: user.username, role: user.role },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed. Please try again." });
  }
});

module.exports = router;
